@extends('layouts.admin')

@section('content')


    <h1>Admin Page</h1>

    <!--HEADER -->
    <div class="header">
        <div class="for-sticky">
            <!--LOGO-->
            <div class="col-md-2 col-xs-6 logo">
                <a href="#"><img width="1000px" height="700px" alt="logo" class="logo-nav" align="middle" src="images/mad1.jpg"></a>
            </div>
            <!--/.LOGO END-->
        </div>
    </div>
@endsection
