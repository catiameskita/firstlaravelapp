<?php $__env->startSection('content'); ?>

<h1><?php echo e($post->title); ?></h1>

<!-- Author -->
<p class="lead">
    by <a href="#"><?php echo e($post->user->name); ?></a>
</p>

<hr>

<!-- Date/Time -->
<p><span class="glyphicon glyphicon-time"></span> Posted <?php echo e($post->created_at->diffForHumans()); ?> </p>

<hr>

<!-- Preview Image -->
<img class="img-responsive" src="<?php echo e($post->photo ? $post->photo->file: $post->photoPlaceHolder()); ?>" alt="">

<hr>

<!-- Post Content -->
<p><?php echo $post->body; ?></p>

<hr>
<div id="disqus_thread"></div>
<script>

    /**
     *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
     *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
    /*
     var disqus_config = function () {
     this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
     this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
     };
     */
    (function() { // DON'T EDIT BELOW THIS LINE
        var d = document, s = d.createElement('script');
        s.src = 'https://coding-app.disqus.com/embed.js';
        s.setAttribute('data-timestamp', +new Date());
        (d.head || d.body).appendChild(s);
    })();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

<script id="dsq-count-scr" src="//coding-app.disqus.com/count.js" async></script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.blog-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>